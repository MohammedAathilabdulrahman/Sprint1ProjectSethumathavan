package com.tns.CollegeService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class CollegeService {
	
		@Autowired
		private CollegeRepository repo;
		
		public void save(College college)
		{
			repo.save(college);
		}
		
		public List<College> getAllCollege()
		{
			return repo.findAll();
		}
		
		public College getCollegeById(Integer id) 
		{
			return repo.findById(id).orElse(null);
		}
		
		public void deleteCollege(Integer id)
		{
			repo.deleteById(id);
		}

		public void updateCollege(Integer id , College updateCollege)
		{
			College existingCollege = repo.findById(id).orElse(null);
			if (existingCollege != null)
			{
				existingCollege.setName(updateCollege.getName());
				existingCollege.setCollegeID(updateCollege.getCollegeID());
				existingCollege.setDean(updateCollege.getDean());
				existingCollege.setLocation(updateCollege.getLocation());
				existingCollege.setEstablishedYear(updateCollege.getEstablishedYear());
				repo.save(existingCollege);
			}
		}
}
