package com.priya.EmployeeServiceModule;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeServiceModuleApplicationTests {

	@Test
	void contextLoads() {
	}

}
